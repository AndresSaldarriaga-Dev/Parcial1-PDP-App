import React, { useRef } from "react";
import FormControl from 'react-bootstrap/FormControl';
import InputGroup from 'react-bootstrap/InputGroup';
import './Header.css';

const Header = ({ setInitialBalance, finalBalance, setFinalBalance }) => {
    const initialBalanceRef = useRef();
    const finalBalanceRef = useRef();


    const handleBalanceInput = () => {
        let value = initialBalanceRef.current.value;
        setInitialBalance(value);
        setFinalBalance(value);
        console.log("Saldo: " + value);
    };

    return (
        <div className="header">
            <div className="left">
                <figure>
                    <a href="#"><img className="logo" src="https://ethereum.org/static/c48a5f760c34dfadcf05a208dab137cc/d1ef9/eth-diamond-rainbow.png" alt="" /></a>
                </figure>
                <h1>App de Ingresos</h1>
            </div>
            <div className="inputs">
                <div className="input">
                    <p>Saldo Inicial:</p>
                    <InputGroup className="mb-3">
                        <InputGroup.Text>$</InputGroup.Text>
                        <FormControl aria-label=""
                            type="number"
                            ref={initialBalanceRef}
                            onChange={handleBalanceInput} />
                    </InputGroup>
                </div>
                <div className="input">
                    <p>Saldo Final:</p>
                    <InputGroup className="mb-3">
                        <InputGroup.Text>$</InputGroup.Text>
                        <FormControl aria-label=""
                            disabled="true"
                            ref={finalBalanceRef}
                            placeholder={finalBalance}
                        />
                    </InputGroup>
                </div>
            </div>
        </div>
    );
};

export default Header;
