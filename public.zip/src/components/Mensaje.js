/*import React, { useState } from 'react';
import './Mensaje.css';
import { Button, Modal, } from "react-bootstrap";

const Mensaje = () => {

    const [show, setShow] = useState(false);
    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);


    return (
                    <Button onClick={handleShow}>
                        <Modal show={show} onHide={handleClose}>
                            <Modal.Header closeButton>
                                <Modal.Title>Mensaje de Error</Modal.Title>
                            </Modal.Header>
                            El valor es insuficiente. Revisar nuevamente.
                        </Modal>
                    </Button>
    )
}

export default Mensaje;*/